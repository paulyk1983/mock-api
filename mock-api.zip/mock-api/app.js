const apicache = require('apicache');

const express = require('express');
const fs = require('fs');

const logger = require('./config/winston');
// Set up mongoose connection
if (process.env.NODE_ENV !== 'production') {
  /* eslint-disable global-require */
  require('dotenv').load();
  /* eslint-enable global-require */
}
const app = express();
const processport = process.env.PORT;
const cache = apicache.middleware;



app.use(cache('60 minutes'));

app.use(require('morgan')('combined', { stream: logger.stream }));


app.use((err, req, res, next) => {
  logger.error(`${err.status || 500} - ${err.message} - ${req.originalUrl} - ${req.method} - ${req.ip}`);

  res.status(err.status || 500);

  res.render('error');
});

app.listen(processport, () => {
  logger.info(`Process up at port ${processport}`);
});

app.all('/pid', (req, res) => {
  res.end(`process ${process.pid} says hello!`);
});

app.get('/geoip/v2.1/country/:ip_address', (req, res) => {
  const data = fs.readFileSync('mocks/geoip_country_by_ip.json', 'utf8');
  const contents = JSON.parse(data);
  const ipAddress = req.params.ip_address;

  contents.traits.ip_address = ipAddress;

  switch (ipAddress) {
    case '209.221.240.193':
      contents.continent.code = 'NA';
      contents.country.iso_code = 'US';

      break;
    case '194.39.218.10':
      contents.continent.code = 'EU';
      contents.country.iso_code = 'DE';
      break;
    default:
      contents.continent.code = 'NOTSET';
      contents.country.iso_code = 'NOTSET';
  }
  res.json(contents).status(200);
});

app.get('/locations', (req,res) => {
  const data = fs.readFileSync('mocks/store-locator.json', 'utf8');
  const contents = JSON.parse(data);
  res.json(contents).status(200);
});
